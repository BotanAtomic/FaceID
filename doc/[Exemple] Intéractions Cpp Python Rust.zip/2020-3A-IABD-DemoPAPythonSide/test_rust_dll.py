from ctypes import *
print("Chargement de la DLL et definition des signatures des méthodes")
my_dll_path = "F:/rust_2020_3A_IABD_DemoPARustLib/target/debug/rust_2020_3A_IABD_DemoPARustLib.dll"

ml_lib = CDLL(my_dll_path)

ml_lib.toto.argtypes = []
ml_lib.toto.restype = c_int

ml_lib.sum_array.argtypes = [c_int * 3, c_int]
ml_lib.sum_array.restype = c_int

print(ml_lib.toto())

print(ml_lib.sum_array((c_int * 3)(*list([1, 2, 3])), 3))
