use std::slice::from_raw_parts;

#[no_mangle]
extern fn toto() -> i32 {
    42
}

#[no_mangle]
extern fn sum_array(arr: *mut i32, arr_size: usize) -> i32 {
    let mut result = 0;
    unsafe {
        let slice = from_raw_parts(arr, arr_size);
        for elt in slice.iter() {
            result += elt;
        }
    }
    return result;
}